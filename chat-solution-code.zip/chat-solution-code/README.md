# WebSockets-ws Chat Application

To run this application, first open up a terminal. Then, run the command below:

```sh
npm install
node server.js
```
